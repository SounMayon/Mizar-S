*******************************************************************************************
GEEETECH Smartto Firmware Upgrador(V2.0)

This tool kit used for upload the firmware for Geeetech printer.
Refer to the git pictures in this directory for how to use the tool.

Attention:
 1.The current version does not support program installation/decompression with 
   non-ASCII character paths.
 2.The current version does not support Hex firmware paths with one or more space character.

Update content:
 1.The tool works with new naming rules(Implemented from February 2019) and is backward
   compatible with older versions.

Release date: January 28, 2019

*******************************************************************************************
Update history:

V1.0(September 18, 2018)
-The first official release.

*******************************************************************************************